import cv2 as cv

img = cv.imread('./imgs/ruido.png')

# Get Channels
b, g, r = cv.split(img)
limiar,black_and_white_img = cv.threshold(r, 127, 255, cv.THRESH_BINARY)

roi = black_and_white_img[103:153,236:286]

cv.imwrite('quadrado_recortado.png', roi)
