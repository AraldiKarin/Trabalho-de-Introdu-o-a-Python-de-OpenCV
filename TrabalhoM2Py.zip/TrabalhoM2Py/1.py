import cv2 as cv
import numpy as np

img = cv.imread("./imgs/um.png")
img2 = cv.imread("./imgs/dois.png")
img3 = cv.imread("./imgs/tres.png")

new_img = cv.imread("./imgs/um.png")


for width in range(img.shape[0]):
  for height in range(img.shape[1]):
    blue_pixel = img3[width,height, 0]
    green_pixel = img[width,height, 1]
    red_pixel = img2[width,height, 2]
    colorful_pixel = (blue_pixel, green_pixel, red_pixel)
    new_img[width, height] =  colorful_pixel

cv.imshow('',new_img)
cv.waitKey(0)